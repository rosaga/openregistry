

<nav class="navbar navbar-default">
<div class="container-fluid">
    <div class="navbar-header">
        <a class="navbar-brand" href="#">masomo bora</a>
    </div>
    <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">Home</a></li>
        <li><a href="register_course.php">Register Course</a></li>
        <li><a href="register_student.php">Register student</a></li>
        <li><a href="courses.php">All courses</a></li>
        <li><a href="students.php">All students</a></li>

    </ul>
</div>
</nav>
